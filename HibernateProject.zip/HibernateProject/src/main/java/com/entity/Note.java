package com.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table(name="notes")
public class Note {
	public Note() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String title;
	@Column(length = 1500)
	private String content;
	private Date addDate;
	/*
	 * public Note(int id, String title, String content, Date addDate) { super();
	 * this.id = new Random().nextInt(100000); this.title = title; this.content =
	 * content; this.addDate = addDate; }
	 */
	public Note(String title, String content, Date addDate) {
		super();
		this.title = title;
		this.content = content;
		this.addDate = addDate;
	}

	
}
